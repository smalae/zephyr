/*
 * Copyright (c) 2025 Silicon Laboratories Inc.
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of the Silicon Labs Master Software License
 * Agreement (MSLA) available at [1].  This software is distributed to you in
 * Object Code format and/or Source Code format and is governed by the sections
 * of the MSLA applicable to Object Code, Source Code and Modified Open Source
 * Code. By using this software, you agree to the terms of the MSLA.
 *
 * [1]: https://www.silabs.com/about-us/legal/master-software-license-agreement
 *
 */
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/linker/devicetree_regions.h>

#if 0
#define BUF_SIZE (30 * 1024)
__aligned(32) static char buffer1[BUF_SIZE];
__aligned(32) static char buffer2[BUF_SIZE];
#endif
#if 1
#define BUF_SIZE (200 * 1024)
__aligned(32) static char buffer1[BUF_SIZE]  Z_GENERIC_SECTION(LINKER_DT_NODE_REGION_NAME(DT_NODELABEL(psram)));
__aligned(32) static char buffer2[BUF_SIZE]  Z_GENERIC_SECTION(LINKER_DT_NODE_REGION_NAME(DT_NODELABEL(psram)));
#endif

static const struct spi_dt_spec spi_spec = SPI_DT_SPEC_GET(DT_NODELABEL(screen),
							   SPI_WORD_SET(16) | SPI_TRANSFER_MSB,
							   0);

static void print_stats(int errno, uint32_t start_time, uint32_t end_time)
{
	uint64_t data_length = BUF_SIZE * BITS_PER_BYTE;
	uint64_t expected_delay = data_length * USEC_PER_SEC / spi_spec.config.frequency;
	uint64_t delay = k_cyc_to_us_ceil64(end_time - start_time);
	uint64_t throughput_kbs = data_length * USEC_PER_SEC / delay / 1000;

	printf("spi_transceive_dt() returned errno %d after %lluus (%llu kb/s, expected %lluus)\n", errno,
	       k_cyc_to_us_ceil64(end_time - start_time), throughput_kbs, expected_delay);
}

int main() {
	uint32_t start_time, end_time;
	struct spi_buf buffers[] = {
		{ .buf = buffer1, .len = BUF_SIZE },
		{ .buf = buffer2, .len = BUF_SIZE },
	};
	const struct spi_buf_set tx = {
		.buffers = buffers + 0,
		.count = 1
	};
	const struct spi_buf_set rx = {
		.buffers = buffers + 1,
		.count = 1
	};
	int ret;

	/* Just check performance of the PSRAM alone */
	start_time = k_cycle_get_32();
	for (int i = 0; i < BUF_SIZE; i++) {
		buffer1[i] = i % 256;
		buffer2[i] = 0xFF;
	}
	start_time = k_cycle_get_32();
	for (int i = 0; i < BUF_SIZE; i++) {
		if (buffer1[i] != i % 256) {
			printf("Data mismatch at offset %d\n", i);
			return 0;
		}
	}
	end_time = k_cycle_get_32();
	print_stats(0, start_time, end_time);
	printf("Init done\n");

	printf("Tx test\n");
	start_time = k_cycle_get_32();
	ret = spi_transceive_dt(&spi_spec, &tx, NULL);
	end_time = k_cycle_get_32();
	print_stats(-ret, start_time, end_time);
	printf("Tx test pass\n");

	printf("Rx test\n");
	memset(buffer2, 0, BUF_SIZE);
	start_time = k_cycle_get_32();
	ret = spi_transceive_dt(&spi_spec, NULL, &rx);
	end_time = k_cycle_get_32();
	for (int i = 0; i < BUF_SIZE; i++) {
		if (buffer2[i] != 0x00) {
			printf("Data mismatch at offset %d: \n", i);
			return 0;
		}
	}
	print_stats(-ret, start_time, end_time);
	printf("Rx test pass\n");

	/* Note: Zcore implementation crash if we pass an Rx buffers set. In contrary the gpDMA with
	 * Zephyr 4.2 does not support if Rx buffers set is NULL.
	 */
	printf("Rx/Tx test\n");
	memset(buffer2, 0, BUF_SIZE);
	start_time = k_cycle_get_32();
	ret = spi_transceive_dt(&spi_spec, &tx, &rx);
	for (int i = 0; i < BUF_SIZE; i++) {
		if (buffer2[i] != i % 256) {
			printf("Data mismatch at offset %d\n", i);
			return 0;
		}
	}
	end_time = k_cycle_get_32();
	print_stats(-ret, start_time, end_time);
        printf("Rx/Tx test pass\n");

	printf("Tx test - 2\n");
	start_time = k_cycle_get_32();
	ret = spi_transceive_dt(&spi_spec, &tx, NULL);
	end_time = k_cycle_get_32();
	print_stats(-ret, start_time, end_time);
	printf("Tx test - 2 pass\n");
	return 0;
}

